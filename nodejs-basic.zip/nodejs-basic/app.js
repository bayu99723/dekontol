const c = require('./coffee');

console.log(coffee);