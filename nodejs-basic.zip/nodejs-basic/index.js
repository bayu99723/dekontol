const moment = require('moment');
 
const date = moment().format("MMMM DD YYYY");
console.log(date);