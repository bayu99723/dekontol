const c = {
    a: 'vicky',
    b: 'aldiano',
}


module.exports = c;